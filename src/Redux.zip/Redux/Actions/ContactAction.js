function convertActionNameToType(actionName) {
    return actionName.replace(/([A-Z])/g, "_$1").toUpperCase();
  }
  
  export const actions = new Proxy(
    {},
    {
       
      get: function(target, prop) { debugger;
        if (target[prop] === undefined)
          return function (args) {
            debugger;
            return {
              type: convertActionNameToType(prop),
              payload:args
            };
          };
        else return target[prop];
      }
    }
  );
  
  
  // set fullname agent
  
  // export function setRule(rule) {
  //   return { type: 'SET_RULE', payload: rule };
  // }
  
  // export function setMobile(mobile) {
  //   return { type: 'SET_MOBILE', payload: mobile };
  // }
  // export function setPersonalEmail(email) {
  //   return { type: 'SET_PERSONALEMAIL', payload: email };
  // }
  // export function setAbout(about) {
  //   return { type: 'SET_ABOUT', payload: about };
  // }
  // export function setPersonalMassege(massege) {
  //   return { type: 'SET_PERSONALMASSEGE', payload: massege };
  // }
  
  // export function setAboutTitle(title) {
  //   return { type: 'SET_ABOUT_TITLE', payload: title };
  // }
  // export function setAboutConnect(connect) {
  //   return { type: 'SET_ABOUT_CONNEC', payload: connect };
  // }
  // export function setPersonalMassegeTitle(title) {
  //   return { type: 'SET_PERSONALMASSEGE_TITLE', payload: title };
  // }
  // export function setPersonalMassegeConnect(connect) {
  //   return { type: 'SET_PERSONALMASSEGE_CONNECT', payload: connect };
  // }
  
  
  
  
  
    