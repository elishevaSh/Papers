import { createStore, combineReducers,applyMiddleware  } from 'redux';
import contactDetails from '../reducers/ContactDetails';
import contactToDelete from '../reducers/ContactDetails';
import {getContactFromServer} from '..//..//Middleware//serverData';
import {editContactFromServer} from '..//..//Middleware//serverData';
import {deleteContactFromCient} from '..//..//Middleware//serverData';
import {getAllContactFromServer} from '..//..//Middleware//serverData';

const state = {
        ContactDetails: contactDetails.contactDetails,
        ContactDetails:contactDetails.contactToDelete
};
// 
const reducer = combineReducers({ contactDetails,contactToDelete});

const store = createStore(reducer, applyMiddleware(getContactFromServer,editContactFromServer,deleteContactFromCient,getAllContactFromServer));
store.dispatch({ type: 'GETALL_CONTACT' });

store.dispatch({ type: 'GET_CONTACT' });
window.store = store;
export default store;


