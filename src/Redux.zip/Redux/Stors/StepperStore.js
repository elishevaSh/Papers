import { createStore, combineReducers,applyMiddleware  } from 'redux';
import contactDetails from '../reducers/ContactDetails';
import contactToDelete from '../reducers/ContactDetails';
import {getContactFromServer} from '..//..//Middleware//serverData';
import {editContactFromServer} from '..//..//Middleware//serverData';
import {deleteContactFromCient} from '..//..//Middleware//serverData';
import {getAllContactFromServer} from '..//..//Middleware//serverData';

const state = {
        StepperComponent: stepperComponent
};
// 
const reducer = combineReducers({ stepperComponent});

const store = createStore(reducer);
window.store = store;
export default store;
