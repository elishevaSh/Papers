import produce from 'immer';
import createReducer from "./reducerUtils";

const initialState = {
     allContact:[],
    contactDetails: {
        // email:"",
        // leadOwner:"",
        // leadSource:"",
        // customerType:"",
        // companySize:"",
        // companyName:"",
        // gender:"",
        // createDateAndTime:"",
        // bestTimeToCall:"",
        // birthday:"",
        // telephon:"",
        // mobileNumber:"",
        // companyAddress:"",
        // state:"",
        // zipcode:"",
        // website:"" , 
        // whatsapp:"" ,
        // linkedIn:"",
        // facebook:"",
        // instagram:"",
        // youTube:""  
        customerType: "",
        leadOwner: "",
leadSource: "",
conversations: (7)["5f2be52dfd54d9310875376e", "5f2be53ffd54d93108753770", "5f427053bafeb01fa32fbb32", "5f4272da0f55fe1fda45019e", "5f42d137d6225f487e4ef57d", "5f44bbd015d5993953f4b45a", "5f44bc0315d5993953f4b45c"],
email: "",
name: "",
numOfUnReadedWaves: 5,
phone: "",
active:true,
starred: true,
thumbnail: "",
user: "",
waves: (5)["5f16b9bb0c179e76221df462", "5f16b9e94ca50676709ddef8", "5f16b9ef4ca50676709ddef9", "5f16b9f74ca50676709ddefa", "5f1fda9084bd461aa7113148"],
__v: 0,
_id: "5f16b7db6c388272bdf741c7"
    },
    currentComponent:"",
    //,
    // contactToDelete:{
    //     _id: "5f16b7db6c388272bdf741c7",
    // }
   
};

const agent = {
    editContact(state, action) {
        // state= store.ContactDetails.contactDetails
        // console.log(state.contactDetails.contact.name);
        debugger;
        state.contactDetails = action.payload;
        // console.log(state.contactDetails.contactDetails)
    },
    setActive(state,action){
        debugger;
        state.contactDetails.active=true;
        debugger;
    },
    setDelete(state,action){
        debugger;
        // state.contactDetails=null;
        debugger;
    },
    setLastcontact(state,action)
    {debugger;
       state.allContact=action.payload
       debugger;
    },
    setContact(state, action) {
        state.contactDetails = action.payload.contact;
        if(state.contactDetails.active==true)
        { debugger;
            state.contactDetails=null;
        }
        else{debugger;
            state.contactDetails = action.payload.contact;
        }
        
        console.log(state.contactDetails);
        debugger;
        
        // console.log(state.contactDetails.contactDetails)
    },
    setDeletecontact(state,action){
    debugger;
       state.contactDetails=null;
       debugger;
    },
    setEmail(state, action) {
        state.contactDetails.email = action.payload;
        debugger;
    },
    setFullName(state, action) {
        debugger;
        state.contactDetails.name = action.payload;
        debugger;
    },
    setLeadOwner(state, action) {
        debugger;
        state.contactDetails.leadOwner = action.payload;
        debugger;
    },
    setLeadSource(state, action) {
        debugger;
        state.contactDetails.leadSource = action.payload;
        debugger;
    },
    setCustomerType(state, action) {
        state.contactDetails.customerType = action.payload;
    },
    setCompanySize(state, action) {
        state.contactDetails.companySize = action.payload;
    },
    setCompanyName(state, action) {
        state.contactDetails.companyName = action.payload;
    },
    setGender(state, action) {
        state.contactDetails.gender = action.payload;
    },
    setCreateDateAndTime(state, action) {
        state.contactDetails.createDateAndTime = action.payload;
    },
    setBestTimeToCall(state, action) {
        state.contactDetails.bestTimeToCall = action.payload;
    },
    setBirthday(state, action) {
        state.contactDetails.birthday = action.payload;
    },
    setPhone(state, action) {
        state.contactDetails.phone = action.payload;
    },
    setMobileNumber(state, action) {
        state.contactDetails.mobileNumber = action.payload;
    },
    setCompanyAddress(state, action) {
        state.contactDetails.companyAddress = action.payload;
    },
    setState(state, action) {
        state.contactDetails.state = action.payload;
    },
    setZipcode(state, action) {
        state.contactDetails.zipcode = action.payload;
    },
    setWebsite(state, action) {
        state.contactDetails.website = action.payload;
    },
    setWhatsapp(state, action) {
        state.contactDetails.whatsapp = action.payload;
    },
    setLinkedIn(state, action) {
        state.contactDetails.linkedIn = action.payload;
    },
    setFacebook(state, action) {
        state.contactDetails.facebook = action.payload;
    },
    setInstagram(state, action) {
        state.contactDetails.instagram = action.payload;
    },
    setYouTube(state, action) {
        state.contactDetails.youTube = action.payload;
    },


};

export default produce((state, action) => createReducer(state, action, agent), initialState);

//delete
// produce((state, action) => {
//     switch (action.type) {
//         case 'SET_FULLNAME':
//             debugger;
//             state.agentDetails.fullName = action.payload;
//             break;
//         case 'SET_RULE':
//             state.agentDetails.rule = action.payload;
//             break;
//         case 'SET_MOBILE':
//             state.agentDetails.mobile = action.payload;
//             break;
//         case 'SET_PERSONALEMAIL':
//             state.agentDetails.personalEmail = action.payload;
//             break;
//         case 'SET_ABOUTTITLE':
//             state.agentDetails.aboutTitle = action.payload;
//             break;
//         case 'SET_ABOUT_CONNECT':
//             state.agentDetails.aboutConnect = action.payload;
//             break;
//         case 'SET_PERSONALMASSEGE_TITLE':
//             state.agentDetails.personalMassegeTitle = action.payload;
//             break;
//         case 'SET_PERSONALMASSEGE_CONNECT':
//             state.agentDetails.personalMassegeConnect = action.payload;
//             break;
//     }
// }, initialState);
