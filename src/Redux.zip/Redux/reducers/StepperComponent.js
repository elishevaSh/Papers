import produce from 'immer';
import createReducer from "./reducerUtils";

const initialState = {
    stepperComponent: {
        nextComponent:false,
    }
};

const agent = {
    setNextComponent(state, action) {
        debugger;
        state.stepperComponent.nextComponent = action.payload;
        debugger;
    }
};

export default produce((state, action) => createReducer(state, action, agent), initialState);

//delete
// produce((state, action) => {
//     switch (action.type) {
//         case 'SET_FULLNAME':
//             debugger;
//             state.agentDetails.fullName = action.payload;
//             break;
//         case 'SET_RULE':
//             state.agentDetails.rule = action.payload;
//             break;
//         case 'SET_MOBILE':
//             state.agentDetails.mobile = action.payload;
//             break;
//         case 'SET_PERSONALEMAIL':
//             state.agentDetails.personalEmail = action.payload;
//             break;
//         case 'SET_ABOUTTITLE':
//             state.agentDetails.aboutTitle = action.payload;
//             break;
//         case 'SET_ABOUT_CONNECT':
//             state.agentDetails.aboutConnect = action.payload;
//             break;
//         case 'SET_PERSONALMASSEGE_TITLE':
//             state.agentDetails.personalMassegeTitle = action.payload;
//             break;
//         case 'SET_PERSONALMASSEGE_CONNECT':
//             state.agentDetails.personalMassegeConnect = action.payload;
//             break;
//     }
// }, initialState);
